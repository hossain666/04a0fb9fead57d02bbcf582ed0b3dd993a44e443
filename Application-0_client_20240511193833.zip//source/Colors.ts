export const colors = {
  primary: '#00684A',
};
